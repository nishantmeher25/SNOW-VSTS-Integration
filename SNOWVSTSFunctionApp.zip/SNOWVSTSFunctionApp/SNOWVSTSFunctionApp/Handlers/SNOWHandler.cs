﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Net.Http.Headers;
using SNOWVSTSFunctionApp.Entities;
using Newtonsoft.Json;
using Microsoft.Azure.WebJobs.Host;

namespace SNOWVSTSFunctionApp.Handlers
{
    public class SNOWHandler
    {
        internal async Task<HttpResponseMessage> UpdateSNOWBug(PatchSNOW snowObject, string snowRequestId, TraceWriter log)
        {
            try
            {
                //PatchSNOW SNOWObject = new PatchSNOW();
                //SNOWObject = snowObject;
                string username = ConfigurationManager.AppSettings["SNOWUserId"].Trim();
                string password = ConfigurationManager.AppSettings["Password"].Trim();
                string url = ConfigurationManager.AppSettings["SNOWRESTAPI"].Trim() + snowRequestId;
                string credentials = Convert.ToBase64String(Encoding.ASCII.GetBytes(username + ":" + password));
                log.Info("Preparing for JSON Request to SNOW");
                var json = JsonConvert.SerializeObject(snowObject);
                var content = new System.Net.Http.StringContent(json, Encoding.UTF8, "application/json");
                log.Info("JSON Input to SNOW : " + json);
                using (var client = new HttpClient())
                {
                    var method = new HttpMethod("PATCH");
                    try
                    {
                        client.DefaultRequestHeaders.Accept.Clear();
                        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", credentials);
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                        //client.DefaultRequestHeaders.Add("Content-Type", "application/json");

                        var request = new HttpRequestMessage(method, url)
                        {
                            Content = content
                        };

                        var response = await client.SendAsync(request);
                        return response;

                    }
                    catch (Exception ex)
                    {
                        log.Error("Error Inside UpdateSNOWBug : " + ex.Message);
                        log.Error("Error Inside UpdateSNOWBug Details : " + ex.StackTrace);
                        throw ex;
                    }
                }
            }
            catch(Exception ex)
            {
                log.Error("Error Outside UpdateSNOWBug : " + ex.Message);
                log.Error("Error Outside UpdateSNOWBug Details : " + ex.StackTrace);
                throw ex;
            }

        }

        
    }
}
