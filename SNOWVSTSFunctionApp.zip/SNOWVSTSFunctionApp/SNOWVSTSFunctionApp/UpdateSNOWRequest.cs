using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Host;
using Newtonsoft.Json;
using SNOWVSTSFunctionApp.Entities;
using SNOWVSTSFunctionApp.Handlers;

namespace SNOWVSTSFunctionApp
{
    public static class UpdateSNOWRequest
    {
        [FunctionName("UpdateSNOWRequest")]
        public static async Task<HttpResponseMessage> Run([HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)]HttpRequestMessage req, TraceWriter log)
        {

            try
            {
                BugDetails bug = null;
                SNOWHandler snowHandler = new SNOWHandler();
                PatchSNOW snowObject = new PatchSNOW();

                log.Info("C# HTTP trigger function processed a request.");            
                var jsonContent = await req.Content.ReadAsStringAsync();
                log.Info("Received Message Details :" + jsonContent);
                //Desrialize the JSON request
                bug = JsonConvert.DeserializeObject<BugDetails>(jsonContent);
                //log.Info("JSON Format Message :" + bug);
                //Assign the JSON objects elements to variable
                snowObject.assigned_to = bug.resource.revision.fields.AssignedTo.ToString().Split('<')[1].Replace('>', ' ');
                var snowRequestId = bug.resource.revision.fields.SNOWRequestId;
                // Log for SNOW paramters
                log.Info("Bug Assigned To : " + snowObject.assigned_to);
                log.Info("Bug Request Id : " + snowRequestId);
                
                // Call the below function to update the SNOW requests                
                HttpResponseMessage httpResponse = await snowHandler.UpdateSNOWBug(snowObject, snowRequestId, log);
                log.Info("Data updated in SNOW Successfully, with status code : " + httpResponse.StatusCode);
                return req.CreateResponse(httpResponse.StatusCode, "Data updated in SNOW Successfully!");

            }
            catch(Exception ex)
            {
                log.Error("Eror Outisde : " + ex.Message);
                log.Error("Eror Outisde Details : " + ex.StackTrace);
                return req.CreateResponse(HttpStatusCode.BadRequest, ex.Message);
            }
        }
        


    }

   
}
