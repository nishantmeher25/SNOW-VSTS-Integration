﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SNOWVSTSFunctionApp.Entities
{
    class BugDetails
    {
       public Resource resource { get; set; }
    }

    class Resource
    {
        //public Fields fields { get; set; }
        public Revision revision { get; set; }
    }

    class Fields
    {
        [JsonProperty("System.AssignedTo")]
        public string AssignedTo { get; set; }
        [JsonProperty("rpmgitrepoAgile.SNOWRequestId")]
        public string SNOWRequestId { get; set; }
      
    }

    class Revision
    {
        //public string AssignedTo { get; set; }
        //public string Description { get; set; }
        public Fields fields { get; set; }
        public int id { get; set; }
        public int rev { get; set; }
    }

    class PatchSNOW
    {
        public string assigned_to { get; set; }
    }


}
